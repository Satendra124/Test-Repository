
function f1() {
    var t1 = 'k';

    if(t1 === 'k') {
        var t2 = '9s';
    }

    console.log(t2);
}